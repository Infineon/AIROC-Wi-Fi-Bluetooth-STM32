var searchData=
[
  ['sleep_5fmode',['sleep_mode',['../structcybt__controller__config__t.html#a1e78be8859c64969d25bb35569b3d8be',1,'cybt_controller_config_t']]],
  ['sleep_5fmode_5fenabled',['sleep_mode_enabled',['../structcybt__controller__sleep__config__t.html#a5fa043774551489ef424852728ec39dc',1,'cybt_controller_sleep_config_t']]],
  ['stop_5fbits',['stop_bits',['../structcybt__hci__uart__config__t.html#abeabe54dd2ff31c28bf8c53f910e0d39',1,'cybt_hci_uart_config_t']]]
];
