var group__platform__trace =
[
    [ "cybt_platform_trace_cb_t", "structcybt__platform__trace__cb__t.html", [
      [ "trace_level", "structcybt__platform__trace__cb__t.html#aff6cbe7223f753c87f870ff5cab4333d", null ]
    ] ],
    [ "CYBT_TRACE_ID_MAIN", "group__platform__trace.html#ga7171cf6d4882d16a4f8095996de39ab2", null ],
    [ "CYBT_TRACE_LEVEL_NONE", "group__platform__trace.html#ga9606ce68152dd02a9f27798d2d68c329", null ],
    [ "cybt_platform_set_trace_level", "group__platform__trace.html#gacff449b9b47250c93eb680a49129d9ec", null ]
];