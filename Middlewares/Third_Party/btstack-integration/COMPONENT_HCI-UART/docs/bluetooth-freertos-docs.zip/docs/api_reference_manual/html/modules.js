var modules =
[
    [ "Bluetooth Platform Configuration", "group__platform__cfg.html", "group__platform__cfg" ],
    [ "Bluetooth Platform Trace", "group__platform__trace.html", "group__platform__trace" ]
];