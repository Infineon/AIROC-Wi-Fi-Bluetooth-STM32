var searchData=
[
  ['bluetooth_20platform_20configuration',['Bluetooth Platform Configuration',['../group__platform__cfg.html',1,'']]],
  ['bluetooth_20platform_20trace',['Bluetooth Platform Trace',['../group__platform__trace.html',1,'']]]
];
