var searchData=
[
  ['controller_5fconfig',['controller_config',['../structcybt__platform__config__t.html#a0ed2b4e529564a9210e5d80c4e59b4bd',1,'cybt_platform_config_t']]]
];
