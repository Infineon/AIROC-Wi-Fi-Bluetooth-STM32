var searchData=
[
  ['uart_5fcts_5fpin',['uart_cts_pin',['../structcybt__debug__uart__config__t.html#ad2a825e22ae429addfec61fe09f3451b',1,'cybt_debug_uart_config_t::uart_cts_pin()'],['../structcybt__hci__uart__config__t.html#a4ab1e920e897867f8e6bcf55c300b677',1,'cybt_hci_uart_config_t::uart_cts_pin()']]],
  ['uart_5frts_5fpin',['uart_rts_pin',['../structcybt__debug__uart__config__t.html#a1442253ba42008c899c18fa135bfeb21',1,'cybt_debug_uart_config_t::uart_rts_pin()'],['../structcybt__hci__uart__config__t.html#a782d923640613d1e4cf5122e02a0c579',1,'cybt_hci_uart_config_t::uart_rts_pin()']]],
  ['uart_5frx_5fpin',['uart_rx_pin',['../structcybt__debug__uart__config__t.html#a109bf7ff2f78d5c2b3d8447ecefbc3e5',1,'cybt_debug_uart_config_t::uart_rx_pin()'],['../structcybt__hci__uart__config__t.html#ac76ec7bcdc6221e98b1bc6fa09b46644',1,'cybt_hci_uart_config_t::uart_rx_pin()']]],
  ['uart_5ftx_5fpin',['uart_tx_pin',['../structcybt__debug__uart__config__t.html#a704afa40225e32731d606d2488a50496',1,'cybt_debug_uart_config_t::uart_tx_pin()'],['../structcybt__hci__uart__config__t.html#aa9fc00eb1a4889f2a526a3175d57c93c',1,'cybt_hci_uart_config_t::uart_tx_pin()']]]
];
