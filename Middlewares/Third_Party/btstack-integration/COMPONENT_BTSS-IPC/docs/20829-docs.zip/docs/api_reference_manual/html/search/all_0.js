var searchData=
[
  ['baud_5frate',['baud_rate',['../structcybt__debug__uart__config__t.html#a60d99e8cf844de2b090ac19c3291ee03',1,'cybt_debug_uart_config_t']]],
  ['baud_5frate_5ffor_5ffeature',['baud_rate_for_feature',['../structcybt__hci__uart__config__t.html#ae8006ab108f355520ca3a97e849bd404',1,'cybt_hci_uart_config_t']]],
  ['baud_5frate_5ffor_5ffw_5fdownload',['baud_rate_for_fw_download',['../structcybt__hci__uart__config__t.html#ab39743cee6567b888d268b63bc46b257',1,'cybt_hci_uart_config_t']]],
  ['bt_5fpower_5fpin',['bt_power_pin',['../structcybt__controller__config__t.html#a9e5cb5adc8c877db1dac24b1aa4cbe9b',1,'cybt_controller_config_t']]],
  ['bluetooth_20platform_20configuration',['Bluetooth Platform Configuration',['../group__platform__cfg.html',1,'']]],
  ['bluetooth_20platform_20trace',['Bluetooth Platform Trace',['../group__platform__trace.html',1,'']]]
];
