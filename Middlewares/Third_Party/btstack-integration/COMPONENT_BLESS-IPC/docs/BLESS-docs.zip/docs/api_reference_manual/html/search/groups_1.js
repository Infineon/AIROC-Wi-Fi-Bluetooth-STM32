var searchData=
[
  ['debug_20uart_20configuration',['Debug UART Configuration',['../group__debug__uart__cfg.html',1,'']]]
];
